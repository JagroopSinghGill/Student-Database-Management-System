/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kungfu;


public class feeobjects 
{
    String studentname, feetype, specification, amount, date, amountdue;
    public feeobjects(String studentname, String feetype, String specification, String amount, String date)
    {
        this.studentname = studentname;
        this.feetype = feetype;
        this.specification = specification;
        this.amount = amount;
        this.date = date;
    }
    
    public static void  main(String args [])
    {
        
    }
    
}
