/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kungfu;

/**
 *
 * @author Jagroop Singh Gill
 */
public class attendanceobject {
    
    String studentname, day, classtype, date;
    public attendanceobject(String studentname, String day, String classtype, String date)
    {
        this.studentname = studentname;
        this.day = day;
        this.classtype = classtype;
        this.date = date;
    }
    
}
