
package kungfu;

import java.applet.Applet;

public class Kungfu extends Applet
{
    public static void main(String[] args) 
    {
        Masterlogin ml = new Masterlogin();
        ml.setVisible(true);
    }
    
}
