/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kungfu;


public class studentobjects 
{
    String studentid, studentname, dateofbirth, mobilenumber, email, address;
    public studentobjects(String studentid, String studentname, String dateofbirth, String mobilenumber, String email, String address)
    {
        this.studentname = studentname;
        this.studentid = studentid;
        this.dateofbirth = dateofbirth;
        this.mobilenumber = mobilenumber;
        this.email = email;
        this.address = address;
    }
    
    public static void  main(String args [])
    {
        
    }
    
}
