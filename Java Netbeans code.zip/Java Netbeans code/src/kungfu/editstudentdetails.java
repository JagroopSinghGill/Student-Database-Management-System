/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kungfu;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Jagroop Singh Gill
 */
public class editstudentdetails extends javax.swing.JFrame {

    String studentid;
    String name, dateofbirth, dateofjoining, membershiptype, membershipexpirydate, email, mobilenumber, housenumber, streetname, cityname, address;
    String dobyear, dobmonth, dobday, dojyear, dojmonth, dojday;
    String membershipfee, rank;
    Calendar cal;
    Date current;
    public editstudentdetails(String studentid) {
        initComponents();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds(0,0,screenSize.width, screenSize.height);
        setVisible(true);
        this.studentid = studentid;
        current = new Date();
        cal = Calendar.getInstance();
        cal.setTime(current);
        filldetails(this.studentid);
    }
    
    public void filldetails(String studentid)
    {
        System.out.println("editing reached");
            try
            {
             Class.forName("com.mysql.jdbc.Driver");
             System.out.println("Driver Loaded");
             Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sys","root","Wahegurusb@13");
             System.out.println("Connection Done");
             Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
             System.out.println("Statement Created");
             ResultSet rs = stmt.executeQuery("Select * from students where studentid='" + studentid + "'");
             System.out.println("Result set creates");
             if(rs.next())
             {
                 tfstudentname.setText(rs.getString("name"));
                 
                 String dateofbirth = rs.getString("dateofbirth");
                 java.sql.Date dob = java.sql.Date.valueOf(dateofbirth);
                 Calendar cal1 = Calendar.getInstance();
                 cal1.setTime(dob);
                 String dobmonth = Integer.toString(cal1.get(Calendar.MONTH)+1);
                 String dobday = Integer.toString(cal1.get(Calendar.DAY_OF_MONTH));
                 String dobyear = Integer.toString(cal1.get(Calendar.YEAR));
                 String dateofjoining = rs.getString("dateofjoining");
                 
                 java.sql.Date doj = java.sql.Date.valueOf(dateofjoining);
                 Calendar cal2 = Calendar.getInstance();
                 cal2.setTime(doj);
                 String dojmonth = Integer.toString(cal2.get(Calendar.MONTH)+1);
                 String dojday = Integer.toString(cal2.get(Calendar.DAY_OF_MONTH));
                 String dojyear = Integer.toString(cal2.get(Calendar.YEAR));
                 
                 cbdobday.getEditor().setItem(dobday);
                 cbdobmonth.getEditor().setItem(dobmonth);
                 cbdobyear.getEditor().setItem(dobyear);
                 
                 cbdojyear.getEditor().setItem(dojyear);
                 cbdojmonth.getEditor().setItem(dojmonth);
                 cbdojday.getEditor().setItem(dojday);
                 
                 cbdobday.setSelectedItem(dobday);
                 cbdobmonth.setSelectedItem(dobmonth);
                 cbdobyear.setSelectedItem(dobyear);
                 cbdojday.setSelectedItem(dojday);
                 cbdojmonth.setSelectedItem(dojmonth);
                 cbdojyear.setSelectedItem(dojyear);
                 
                 cbmembershiptype.getEditor().setItem(rs.getString("membershiptype"));
                 cbmembershiptype.setSelectedItem(rs.getString("membershiptype"));
                 
                 tfemail.setText(rs.getString("email"));
                 tfmobilenumber.setText(rs.getString("mobilenumber"));
                 
                 String currentrank = rs.getString("currentrank");
                 cbrank.getEditor().setItem(currentrank);
                 cbrank.setSelectedItem(currentrank);
                 
                 String address = rs.getString("address");
                 String a[] = address.split(", ");
                 
                 tfhousenumber.setText(a[0]);
                 tfstreetnumber.setText(a[1]);
                 tfcityname.setText(a[2]);
             }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
    }

    private editstudentdetails() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tfstudentname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cbdobyear = new javax.swing.JComboBox<>();
        cbdobmonth = new javax.swing.JComboBox<>();
        cbdobday = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cbdojyear = new javax.swing.JComboBox<>();
        cbdojday = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cbmembershiptype = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        tfmobilenumber = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tfemail = new javax.swing.JTextField();
        btnext = new javax.swing.JButton();
        cbdojmonth = new javax.swing.JComboBox<>();
        btcancel = new javax.swing.JButton();
        addresspanel = new javax.swing.JPanel();
        tfstreetnumber = new javax.swing.JTextField();
        tfcityname = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tfhousenumber = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        cbrank = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("PLEASE FILL THE DETAILS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 17;
        gridBagConstraints.ipady = 14;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(29, 29, 0, 0);
        getContentPane().add(jLabel1, gridBagConstraints);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("NAME");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipady = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 48, 0, 0);
        getContentPane().add(jLabel2, gridBagConstraints);

        tfstudentname.setToolTipText("name");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 83;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 193;
        gridBagConstraints.ipady = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(20, 25, 0, 98);
        getContentPane().add(tfstudentname, gridBagConstraints);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("DATE OF BIRTH");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 9;
        gridBagConstraints.ipady = 13;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 48, 0, 0);
        getContentPane().add(jLabel3, gridBagConstraints);

        cbdobyear.setEditable(true);
        cbdobyear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Year", "1920", "1921", "1922", "1923", "1924", "1925", "1926", "1927", "1928", "1929", "1930", "1931", "1932", "1933", "1934", "1935", "1936", "1937", "1938", "1939", "1940", "1941", "1942", "1943", "1944", "1945", "1946", "1947", "1948", "1949", "1950", "1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958", "1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013" }));
        cbdobyear.setMaximumSize(new java.awt.Dimension(55, 20));
        cbdobyear.setPreferredSize(new java.awt.Dimension(55, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 7;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 25, 0, 0);
        getContentPane().add(cbdobyear, gridBagConstraints);

        cbdobmonth.setEditable(true);
        cbdobmonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 18;
        gridBagConstraints.ipadx = -31;
        gridBagConstraints.ipady = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(19, 6, 0, 0);
        getContentPane().add(cbdobmonth, gridBagConstraints);

        cbdobday.setEditable(true);
        cbdobday.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Day", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cbdobday.setPreferredSize(new java.awt.Dimension(55, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 54;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 6, 0, 98);
        getContentPane().add(cbdobday, gridBagConstraints);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("DATE OF JOINING");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.ipadx = 13;
        gridBagConstraints.ipady = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 48, 0, 0);
        getContentPane().add(jLabel4, gridBagConstraints);

        cbdojyear.setEditable(true);
        cbdojyear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Year", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020" }));
        cbdojyear.setPreferredSize(new java.awt.Dimension(55, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 7;
        gridBagConstraints.gridheight = 3;
        gridBagConstraints.ipady = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(19, 25, 0, 0);
        getContentPane().add(cbdojyear, gridBagConstraints);

        cbdojday.setEditable(true);
        cbdojday.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Day", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cbdojday.setPreferredSize(new java.awt.Dimension(55, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 54;
        gridBagConstraints.gridheight = 3;
        gridBagConstraints.ipady = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(19, 6, 0, 98);
        getContentPane().add(cbdojday, gridBagConstraints);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("MEMBERSHIP TYPE");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.ipadx = 16;
        gridBagConstraints.ipady = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(20, 48, 0, 0);
        getContentPane().add(jLabel5, gridBagConstraints);

        cbmembershiptype.setEditable(true);
        cbmembershiptype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Silver - 1 Month Plan ($100)", "Gold   - 2 Months Plan ($180)", "Platinum - 3 Months Plan ($265)", "Diamond - 6 Months Plan ($500)" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 53;
        gridBagConstraints.ipadx = 17;
        gridBagConstraints.ipady = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 25, 0, 0);
        getContentPane().add(cbmembershiptype, gridBagConstraints);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("MOBILE NUMBER");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.ipadx = 30;
        gridBagConstraints.ipady = 11;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 48, 0, 0);
        getContentPane().add(jLabel6, gridBagConstraints);

        tfmobilenumber.setToolTipText("name");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.gridwidth = 83;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 193;
        gridBagConstraints.ipady = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(20, 25, 0, 98);
        getContentPane().add(tfmobilenumber, gridBagConstraints);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("EMAIL");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.ipadx = 97;
        gridBagConstraints.ipady = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(15, 48, 0, 0);
        getContentPane().add(jLabel7, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.gridwidth = 83;
        gridBagConstraints.ipadx = 193;
        gridBagConstraints.ipady = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(15, 25, 0, 98);
        getContentPane().add(tfemail, gridBagConstraints);

        btnext.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnext.setText("NEXT");
        btnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnextActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 15;
        gridBagConstraints.gridwidth = 6;
        gridBagConstraints.ipadx = 29;
        gridBagConstraints.ipady = 15;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 34, 11, 0);
        getContentPane().add(btnext, gridBagConstraints);

        cbdojmonth.setEditable(true);
        cbdojmonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 18;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = -31;
        gridBagConstraints.ipady = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(19, 6, 0, 0);
        getContentPane().add(cbdojmonth, gridBagConstraints);

        btcancel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btcancel.setText("CANCEL");
        btcancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btcancelActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 15;
        gridBagConstraints.gridwidth = 24;
        gridBagConstraints.ipadx = 11;
        gridBagConstraints.ipady = 15;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 42, 11, 0);
        getContentPane().add(btcancel, gridBagConstraints);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("POSTAL ADDRESS");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("HOUSE NO.");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("STREET NAME");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("CITY & COUNTRY");

        javax.swing.GroupLayout addresspanelLayout = new javax.swing.GroupLayout(addresspanel);
        addresspanel.setLayout(addresspanelLayout);
        addresspanelLayout.setHorizontalGroup(
            addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addresspanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addresspanelLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(addresspanelLayout.createSequentialGroup()
                        .addGroup(addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(25, 25, 25)
                        .addGroup(addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfhousenumber, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tfstreetnumber)
                            .addComponent(tfcityname))))
                .addContainerGap())
        );
        addresspanelLayout.setVerticalGroup(
            addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addresspanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfhousenumber, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfstreetnumber, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(addresspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfcityname, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.gridwidth = 89;
        gridBagConstraints.ipadx = 135;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 48, 0, 98);
        getContentPane().add(addresspanel, gridBagConstraints);

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("RANK");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 46;
        gridBagConstraints.ipady = 11;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(21, 48, 0, 0);
        getContentPane().add(jLabel12, gridBagConstraints);

        cbrank.setEditable(true);
        cbrank.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "White", "Yellow", "Half Green", "Green", "Half Blue", "Blue", "Half Red", "Red", "Half Black", "Black" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 83;
        gridBagConstraints.ipadx = 101;
        gridBagConstraints.ipady = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(19, 25, 0, 98);
        getContentPane().add(cbrank, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void calculateexpiry()
    {
        cal.set(Calendar.YEAR,  Integer.parseInt(dojyear));
        cal.set(Calendar.MONTH, Integer.parseInt(dojmonth));
        cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dojday));
        
        if(membershiptype.equalsIgnoreCase("Silver - 1 Month Plan ($100)"))
        {
          cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH)+1)); 
        }
        else if(membershiptype.equalsIgnoreCase("Gold   - 2 Months Plan ($180)"))
        {
          cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH)+2));
        }
        if(membershiptype.equalsIgnoreCase("Platinum - 3 Months Plan ($265)"))
        {
          cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH)+3));
        }
        if(membershiptype.equalsIgnoreCase("Diamond - 6 Months Plan ($500)"))
        {
          cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH)+6));
        }

        membershipexpirydate = cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.MONTH) + "-" + cal.get(Calendar.DAY_OF_MONTH);
    }
     
     public void checkfields()
    {
        String a[] = {name, dobyear, dobmonth, dobday, dojyear, dojmonth, dojday, membershiptype, email, mobilenumber, housenumber, streetname, cityname};
        int flag=0;
        for(String b : a)
        {
            if(b.isEmpty())
            {
                flag=1;
            }
        }
        if(flag==1)
        {
          JOptionPane.showMessageDialog(rootPane, "Please provide details in all the fields","ERROR", JOptionPane.ERROR_MESSAGE);    
        }
    }
    public void addrank()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loaded");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sys","root","Wahegurusb@13");
            System.out.println("Connection Done");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs1 = stmt.executeQuery("Select * from ranks where rankname='" + rank + "'");
            rs1.next();
            String rankid = rs1.getString("rankid");
            ResultSet rs2 = stmt.executeQuery("Select * from progress where studentid='" + studentid + "' order by dateofawarded desc limit 1");
            System.out.println("Result set creates");
           
            rs2.next();
            if(!(rankid.equals(rs2.getString("rankid"))));
            {
              rs2.moveToInsertRow();
              rs2.updateString("rankid", rankid);
              rs2.updateString("studentid", studentid);
              
              Date current = new Date();
              Calendar cal = Calendar.getInstance();
              cal.setTime(current);
              
              String dateofawarded = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH)+1) + "-" + cal.get(Calendar.DAY_OF_MONTH);
              
              rs2.updateString("dateofawarded", dateofawarded);
              rs2.insertRow();
              rs1.close();
              rs2.close();    
            }
            
 
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
 
     
    private void btnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnextActionPerformed
        
     int ans = JOptionPane.showConfirmDialog(this, "Details will be saved as mentioned.... Continue??", "Confirmation", JOptionPane.YES_NO_OPTION);
          
     if(ans==JOptionPane.YES_OPTION)
      {
        name = tfstudentname.getText();
        
        dobyear = (String) cbdobyear.getSelectedItem();
        dobmonth = (String) cbdobmonth.getSelectedItem();
        dobday = (String) cbdobday.getSelectedItem();
        dojyear = (String) cbdojyear.getSelectedItem();
        dojmonth = (String) cbdojmonth.getSelectedItem();
        dojday = (String) cbdojday.getSelectedItem();
        
        membershiptype = (String)cbmembershiptype.getSelectedItem();
        mobilenumber = tfmobilenumber.getText();
        email = tfemail.getText();
        rank = (String) cbrank.getSelectedItem();
        
        housenumber = tfhousenumber.getText();
        streetname = tfstreetnumber.getText();
        cityname = tfcityname.getText();
        
        checkfields();
        
        address = housenumber + ", " + streetname + ", " + cityname;
        dateofbirth = dobyear + "-" + dobmonth + "-" + dobday;
        dateofjoining = dojyear + "-" + dojmonth + "-" + dojday;
        System.out.println(dateofbirth);
        calculateexpiry();
        try
            {
             Class.forName("com.mysql.jdbc.Driver");
             System.out.println("Driver Loaded");
             Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sys","root","Wahegurusb@13");
             System.out.println("Connection Done");
             Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
             System.out.println("Statement Created");
             ResultSet rs = stmt.executeQuery("Select * from students where studentid='" + studentid + "'");
             System.out.println("Result set creates");
             
            rs.next();
            rs.updateString("name", name);
            rs.updateString("dateofbirth", dateofbirth);
            rs.updateString("dateofjoining", dateofjoining);
            rs.updateString("membershiptype", membershiptype);
            rs.updateString("membershipexpirydate", membershipexpirydate);
            rs.updateString("mobilenumber", mobilenumber);
            rs.updateString("email", email);
            rs.updateString("currentrank",rank);
            rs.updateString("address", address);
            rs.updateRow();
            
            rs.close();  
            
            addrank();
            
            new editparentsdetails(studentid).setVisible(true);
            this.dispose();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
           }
        

    }//GEN-LAST:event_btnextActionPerformed

    private void btcancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btcancelActionPerformed
                    this.dispose();
    }//GEN-LAST:event_btcancelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new editstudentdetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel addresspanel;
    private javax.swing.JButton btcancel;
    private javax.swing.JButton btnext;
    private javax.swing.JComboBox<String> cbdobday;
    private javax.swing.JComboBox<String> cbdobmonth;
    private javax.swing.JComboBox<String> cbdobyear;
    private javax.swing.JComboBox<String> cbdojday;
    private javax.swing.JComboBox<String> cbdojmonth;
    private javax.swing.JComboBox<String> cbdojyear;
    private javax.swing.JComboBox<String> cbmembershiptype;
    private javax.swing.JComboBox<String> cbrank;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField tfcityname;
    private javax.swing.JTextField tfemail;
    private javax.swing.JTextField tfhousenumber;
    private javax.swing.JTextField tfmobilenumber;
    private javax.swing.JTextField tfstreetnumber;
    private javax.swing.JTextField tfstudentname;
    // End of variables declaration//GEN-END:variables
}
