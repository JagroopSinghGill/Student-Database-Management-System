-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: sys
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feeitems`
--

DROP TABLE IF EXISTS `feeitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `feeitems` (
  `itemid` int(11) NOT NULL,
  `itemtype` varchar(45) NOT NULL,
  `itemspecification` varchar(45) NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeitems`
--

LOCK TABLES `feeitems` WRITE;
/*!40000 ALTER TABLE `feeitems` DISABLE KEYS */;
INSERT INTO `feeitems` VALUES (1,'membership','Silver(1 Month-$100)'),(2,'membership','Gold(2 Months-$180)'),(3,'membership','Platinum(3 Months-$265)'),(4,'membership','Diamond(6 Months-$500)'),(5,'test','Yellow Level($10)'),(6,'test','Half Green Level($20)'),(7,'test','Green Level($30)'),(8,'test','Half Blue Level($40)'),(9,'test','Blue Level($50)'),(10,'test','Half Red Level($60)'),(11,'test','Red Level($70)'),(12,'test','Half Black($80)'),(13,'test','Black($100)'),(14,'product','Sash($5)'),(15,'product','Belts($3)'),(16,'product','uniform($15)'),(17,'product','Shoe($20)'),(18,'product','Iron Palm($10)'),(19,'product','Broadsword($20)'),(20,'product','Wall Bags($13)');
/*!40000 ALTER TABLE `feeitems` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-21 23:04:01
