-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: sys
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `students` (
  `studentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `dateofbirth` date NOT NULL,
  `dateofjoining` date NOT NULL,
  `mobilenumber` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `membershiptype` varchar(45) NOT NULL,
  `membershipexpirydate` date NOT NULL,
  `currentrank` varchar(45) NOT NULL DEFAULT 'white',
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`studentid`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (49,'jagroop singh','1996-01-09','2018-03-01','3657735867','jagroopsinghgill11@gmail.com','479, Rankin Ave, Windsor','Diamond - 6 Months Plan ($500)','2018-09-01','Half Blue','inactive'),(50,'shubhdeep kaur','1995-12-25','2018-04-01','+13657735876','s.randhawa025@gmail.com','511, rankin ave, Windsor','Platinum - 3 Months Plan ($265)','2018-07-01','white','active'),(51,'Gagandeep Singh','1995-05-15','2018-06-21','+12262805618','gagansaini115a@gmail.com','479, Rankin Ave, Windsor','Gold   - 2 Months Plan ($180)','2018-08-21','white','inactive'),(56,'vsdvsv','1922-05-12','2013-04-04','svsdv','sdvsdvsd','vsdvdsv, dsvsdvsdv, svsdvsdv','Platinum - 3 Months Plan ($265)','2013-07-04','white','active'),(57,'Vinayak Sharda','1983-07-27','2018-06-21','2269995665','sharda@gmail.com','768, Oulette , Windsor,CA','Diamond - 6 Months Plan ($500)','2019-00-21','white','active'),(58,'Dinesh Bhagat','1989-10-22','2018-06-21','3364592658','bhagat@gmail.com','5869, University Ave, Windsor, CA','Diamond - 6 Months Plan ($500)','2019-00-21','white','active'),(59,'Inderjit Singh Saini','1983-08-26','2018-06-21','3362562369','saini@gmail.com','992, Mckay, Windsor, CA','Diamond - 6 Months Plan ($500)','2019-00-21','white','active');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-21 23:04:04
